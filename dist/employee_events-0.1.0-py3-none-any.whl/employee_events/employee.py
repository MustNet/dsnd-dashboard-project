# python-package/employee_events/employee.py
from .query_base import QueryBase
from .sql_execution import QueryMixin  # falls QueryBase es nicht schon hat

# try to obtain connect_db helper from report.utils (if present)
try:
    from report.utils import connect_db
except Exception:
    connect_db = None


class Employee(QueryBase):
    """
    Employee model adapted to the package DB schema (tables: employee, team, employee_events, notes).
    """

    name = "employee"  # keep this if other code relies on it

    def __init__(self, *args, **kwargs):
        # call parent init if present
        try:
            super().__init__(*args, **kwargs)
        except Exception:
            pass

        # try to attach a package-provided DB connection (non-fatal)
        try:
            if connect_db is not None:
                self.conn = connect_db()
        except Exception:
            pass

    def names(self):
        """
        Robust: versuche zuerst first_name || ' ' || last_name,
        und falls das wegen fehlender Spalten in der DB fehlschlägt,
        versuche als Fallback full_name.
        """
        sql_preferred = """
        SELECT first_name || ' ' || last_name AS full_name, employee_id
        FROM employee
        ORDER BY employee_id;
        """
        sql_fallback = """
        SELECT full_name, employee_id
        FROM employee
        ORDER BY employee_id;
        """
        try:
            return self.query(sql_preferred)
        except Exception:
            # fallback auf full_name (falls vorhanden)
            return self.query(sql_fallback)

    def username(self, id):
        """
        Robust: wie names(), aber für einen einzelnen employee_id.
        """
        try:
            eid = int(id)
        except Exception:
            eid = -1

        sql_preferred = f"""
        SELECT first_name || ' ' || last_name AS full_name
        FROM employee
        WHERE employee_id = {eid};
        """
        sql_fallback = f"""
        SELECT full_name
        FROM employee
        WHERE employee_id = {eid};
        """
        try:
            return self.query(sql_preferred)
        except Exception:
            return self.query(sql_fallback)

    def model_data(self, id):
        """
        Build pandas DataFrame with counts of positive/negative events for the employee.
        Relies on table `employee_events` with columns (employee_id, event_type).
        Returns: pandas.DataFrame via self.pandas_query(sql)
        """
        try:
            eid = int(id)
        except Exception:
            eid = -1

        sql = f"""
        SELECT
            SUM(CASE WHEN event_type = 'positive' THEN 1 ELSE 0 END) AS positive_events,
            SUM(CASE WHEN event_type = 'negative' THEN 1 ELSE 0 END) AS negative_events
        FROM employee_events
        WHERE employee_id = {eid};
        """
        # QueryBase should provide pandas_query — returns a DataFrame
        return self.pandas_query(sql)
